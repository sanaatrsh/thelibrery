

<?php $__env->startSection('title'); ?>
    students
<?php $__env->stopSection(); ?>
<!-- Content Wrapper. Contains page content -->
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Students</h1>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <!-- /.card -->

                        <div class="card">
                            <div class="card-header">
                                

                                <a href="<?php echo e(route('students.create')); ?>" class="btn btn-block btn-primary btn-lg"
                                    style="width: 200px;height: 50px">Add
                                    New Student
                                </a>



                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>University id</th>
                                            <th>Major</th>
                                            <th>Birth</th>
                                            <th>Email</th>
                                            <th>Phone Number</th>
                                            <th>Address</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>

                                                <td><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></a>
                                                </td>
                                                <td><?php echo e($student->university_id); ?></td>
                                                <td><?php echo e($student->major); ?></td>
                                                 <td><?php echo e($student->birth); ?></td>
                                                <td><?php echo e($student->email); ?></td>
                                                <td><?php echo e($student->phone_number); ?></td>
                                                <td><?php echo e($student->address); ?></td>
                                                <td>
                                                    <form action="<?php echo e(route('books.postBorrow', [$book->id, $student->id])); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-block btn-primary">select student</button>
                                                    </form>
                                                </td>


                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="9">No students Yet!</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <div style="align-items:center;" class="card-footer clearfix">
        <ul class="pagination pagination-sm m-0 float-right">
            <?php echo e($students->links()); ?> </ul>
    </div>
<?php $__env->stopSection(); ?>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->


<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('../../plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src=".<?php echo e(asset('./../plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    
    <script>
        // $(function() {
        //     $("#example1").DataTable({
        //         "responsive": true,
        //         "lengthChange": false,
        //         "autoWidth": false,
        //         "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        //     }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        //     $('#example2').DataTable({
        //         "paging": true,
        //         "lengthChange": false,
        //         "searching": false,
        //         "ordering": true,
        //         "info": true,
        //         "autoWidth": false,
        //         "responsive": true,
        //     });
        // });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\library\resources\views/admin/borrow.blade.php ENDPATH**/ ?>