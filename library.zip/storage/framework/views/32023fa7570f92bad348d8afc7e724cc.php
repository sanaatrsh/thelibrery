

<?php $__env->startSection('title'); ?>
    Books
<?php $__env->stopSection(); ?>
<!-- Content Wrapper. Contains page content -->
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Books</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="/">Home</a></li>
                            <li class="breadcrumb-item active">Books</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <!-- /.card -->

                        <div class="card">
                            <div class="card-header">
                                
                                <?php if(Auth::user()): ?>
                                    <a href="<?php echo e(route('books.create')); ?>" class="btn btn-block btn-primary btn-lg"
                                        style="width: 200px;height: 50px">Add
                                        New Book
                                    </a>
                                <?php endif; ?>


                            </div>
                            <!-- /.card-header -->
                            <div class="card-body" style="overflow-x:auto;">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Author</th>
                                            <th>Category</th>
                                            <th>availability</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td>
                                                    <?php if($book->image): ?>
                                                        <img src="<?php echo e(asset('storage/' . $book->image)); ?>" alt=""
                                                            height="50px">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('images\manual-forensic-taphonomy-2nd-edition-pdf.jpg')); ?>"
                                                            alt="" height="50px">
                                                    <?php endif; ?>
                                                </td>
                                                <td><a href='<?php echo e(route('books.show', $book->id)); ?>'><?php echo e($book->name); ?></a>
                                                </td>
                                                <td><?php echo e($book->author->name); ?></td>
                                                <td><?php echo e($book->category->name); ?></td>

                                                
                                                <td><?php echo e($book->availability); ?></td>
                                                <?php if(Auth::user()): ?>
                                                    <?php if($book->availability == 'available'): ?>
                                                        <th><a class="btn btn-block btn-primary"
                                                                href="<?php echo e(route('books.borrow', $book->id)); ?>">Borrow</a>
                                                        </th>
                                                    <?php else: ?>
                                                        <th><a class="btn btn-block btn-secondary"
                                                                href="<?php echo e(route('books.return', $book->id)); ?>">Return</a>
                                                        </th>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="9">No Books Yet!</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <div style="align-items:center;" class="card-footer clearfix">
        <ul class="pagination pagination-sm m-0 float-right">
            <?php echo e($books->links()); ?> </ul>
    </div>
<?php $__env->stopSection(); ?>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->


<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('../../plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src=".<?php echo e(asset('./../plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../../plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    
    <script>
        // $(function() {
        //     $("#example1").DataTable({
        //         "responsive": true,
        //         "lengthChange": false,
        //         "autoWidth": false,
        //         "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        //     }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        //     $('#example2').DataTable({
        //         "paging": true,
        //         "lengthChange": false,
        //         "searching": false,
        //         "ordering": true,
        //         "info": true,
        //         "autoWidth": false,
        //         "responsive": true,
        //     });
        // });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\library\resources\views/admin/books.blade.php ENDPATH**/ ?>