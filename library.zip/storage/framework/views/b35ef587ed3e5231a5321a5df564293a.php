

<?php $__env->startSection('title'); ?>
    <?php echo e($author->name); ?>

<?php $__env->stopSection(); ?>
<!-- Content Wrapper. Contains page content -->
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($author->name); ?></h1>
                    </div>

                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-body row">
                    <div class="col-5 text-center d-flex align-items-center justify-content-center">
                        <div class="">
                            <?php if($author->image): ?>
                                <img src="<?php echo e(asset('storage/' . $author->image)); ?>" alt="" width="60%"
                                    height="60%">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images\manual-forensic-taphonomy-2nd-edition-pdf.jpg')); ?>"
                                    alt="" width="60%" height="60%">
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="col-7">
                        <div class="form-group">
                            <h5>Name</h5>
                            <h4><?php echo e($author->name); ?></h4>
                        </div>

                        <div class="form-group">
                            <h5>Nationality</h5>
                            <h4><?php echo e($author->nationality); ?></h4>
                        </div>

                        <div class="form-group">
                            <h5>Birth</h5>
                            <h4><?php echo e($author->birth); ?></h4>
                        </div>
                        <div class="form-group">
                            <h5>biography</h5>
                            <p><?php echo e($author->biography); ?></p>
                        </div>
                        <div class="form-group">
                            <h5>Books</h5>
                            <?php if($author->books()->count()): ?>
                                <?php $__currentLoopData = $author->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul>
                                        <li><a href="<?php echo e(route('books.show', $book->id)); ?>"><?php echo e($book->name); ?></li></a>

                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>No Book For This Author</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(Auth::user()): ?>
                    <a class="btn btn-block btn-info" href="<?php echo e(route('authors.edit', $author->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('authors.destroy', $author->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-block btn-danger">Delete</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>

        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\library\resources\views/admin/author/author.blade.php ENDPATH**/ ?>