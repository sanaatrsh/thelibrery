<?php echo e($slot); ?>

<?php /**PATH E:\project\library\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>