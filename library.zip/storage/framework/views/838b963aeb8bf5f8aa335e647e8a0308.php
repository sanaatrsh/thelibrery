<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
with font-awesome or any other icon font library -->
        
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item['title'] == 'Students'): ?>
        <?php if(Auth::user()): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route($item['route'])); ?>"
                            class="nav-link <?php echo e(Route::is($item['active']) ? 'active' : ''); ?>">
                            <i class="<?php echo e($item['icon']); ?>"></i>
                            <p>
                                <?php echo e($item['title']); ?>

                                
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php else: ?>
                <li class="nav-item">
                    <a href="<?php echo e(route($item['route'])); ?>"
                        class="nav-link <?php echo e(Route::is($item['active']) ? 'active' : ''); ?>">
                        <i class="<?php echo e($item['icon']); ?>"></i>
                        <p>
                            <?php echo e($item['title']); ?>

                            
                        </p>
                    </a>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>
<?php /**PATH E:\project\library\resources\views/components/nav-component.blade.php ENDPATH**/ ?>