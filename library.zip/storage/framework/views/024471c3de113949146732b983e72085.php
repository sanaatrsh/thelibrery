

<?php $__env->startSection('title'); ?>
    <?php echo e($book->name); ?>

<?php $__env->stopSection(); ?>
<!-- Content Wrapper. Contains page content -->
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($book->name); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active"><?php echo e($book->name); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="card">
                <div class="card-body row">
                    <div class="col-5 text-center d-flex align-items-center justify-content-center">
                        <div class="">
                            <?php if($book->image): ?>
                                <img src="<?php echo e(asset('storage/' . $book->image)); ?>" alt="" width="60%"
                                    height="60%">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images\manual-forensic-taphonomy-2nd-edition-pdf.jpg')); ?>"
                                    alt="" width="60%" height="60%">
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="col-7">
                        <div class="form-group">
                            <h5>Name</h5>
                            <h4><?php echo e($book->name); ?></h4>
                        </div>
                        <div class="form-group">
                            <h5>Author</h5>
                            <h4><?php echo e($book->author->name); ?></h4>
                            <a href="<?php echo e(route('authors.show', $book->author->id)); ?>">
                                <p>show author</p>
                            </a>
                        </div>
                        <div class="form-group">
                            <h5>Category</h5>
                            <h4><?php echo e($book->category->name); ?></h4>
                        </div>
                        <div class="form-group">
                            <h5>Tags</h5>
                            <h4><?php echo e(implode(', ', $book->tags()->pluck('name')->toArray())); ?></h4>
                        </div>
                        <div class="form-group">
                            <h5>Pages Number</h5>
                            <h4><?php echo e($book->pages_number); ?></h4>
                        </div>
                        <div class="form-group">
                            <h5>Publisher</h5>
                            <h4><?php echo e($book->publisher); ?></h4>
                            <p><?php echo e($book->publisher_date); ?></p>
                        </div>
                        <div class="form-group">
                            <h5>Description</h5>
                            <p><?php echo e($book->description); ?></p>
                        </div>
                        <div class="form-group">
                            <h5>Availability</h5>
                            <h4><?php echo e($book->availability); ?></h4>
                        </div>
                    </div>
                    <?php if(Auth::user()): ?>
                        <?php if($book->availability == 'available'): ?>
                            <a class="btn btn-block btn-primary" href="<?php echo e(route('books.borrow', $book->id)); ?>">Borrow</a>
                        <?php else: ?>
                            <a class="btn btn-block btn-secondary" href="<?php echo e(route('books.return', $book->id)); ?>">Return</a>
                        <?php endif; ?>
                        <a class="btn btn-block btn-info" href="<?php echo e(route('books.edit', $book->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-block btn-danger">Delete</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\library\resources\views/admin/book.blade.php ENDPATH**/ ?>